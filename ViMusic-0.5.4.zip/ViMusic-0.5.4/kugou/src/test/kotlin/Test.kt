import kotlinx.coroutines.runBlocking
import org.junit.Test

class Test {
    @Test
    @Throws(Exception::class)
    fun test() {
        runBlocking {
        }
    }
}
